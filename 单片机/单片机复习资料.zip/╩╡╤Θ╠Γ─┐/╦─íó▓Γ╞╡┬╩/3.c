#include <STC12C5A60S2.H> //#include<reg51.h>

unsigned char temp;
unsigned char count;
sbit LED = P2^0;
void main()
{
	TMOD = 0X15;//��ʱ��һ��ʱ��0����
	TH1 = (65535 - 50000)/256;//Ĭ��12M����
	TL1 = (65535 - 50000)%256;
	TH0 = TL0 = 0;
	ET1 = 1;
	TR1 = 1;
	ET0 = 1;
	TR0 = 1;
	EA = 1;

	while(1)
	{
		if(temp > 50)
		{
			LED = 0;
		}
		else
		{
			LED = 1;
		}
		
	}
}

void T1() interrupt 3
{
	TH1 = (65535 - 50000)/256;//Ĭ��12M����
	TL1 = (65535 - 50000)%256;
	
	count++;
	if (count == 20)
	{
		count = 0;
		temp = TH0 * 256 + TL0;
		TH0 = TL0 = 0;
	}
}
