#include <STC12C5A60S2.H> //#include<AT89C52.h>

//���������
unsigned char duanxuan[] = {0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f,0x40};

sbit key = P3^2;
unsigned char count = 22;

void delay(unsigned int mm)
{
	while(mm--);
}

void DisplaySMG(unsigned char dat, unsigned char pos)
{
	P0 = 0X00;//����
    P2 = ~(0X01 << pos);//λѡ
	P0 = duanxuan[dat];//��ѡ
	delay(30);
}

void main()
{
	EX0 = 1;
	IT0 = 1;
	EA = 1;
	
	while(1)
	{
		DisplaySMG(count/10,0);
		DisplaySMG(count%10,1);
	}
}
void Int0() interrupt 0
{
	if (key == 0) // �жϰ����Ƿ���
	{
		count++;
		while(key == 0);//�ȴ��ɼ�
	}
	if (count == 32)
	{
		count = 22;
	}
}