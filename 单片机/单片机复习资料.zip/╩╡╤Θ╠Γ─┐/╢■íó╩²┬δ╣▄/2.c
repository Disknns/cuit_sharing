#include <STC12C5A60S2.H> //#include<AT89C52.h>

//���������
unsigned char duanxuan[] = {0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f,0x40};

sbit key = P3^3;
unsigned char count = 0;

void delay(unsigned int mm)
{
	while(mm--);
}

void DisplaySMG(unsigned char dat, unsigned char pos)
{
	P0 = 0X00;//����
    P2 = ~(0X01 << pos);//λѡ
	P0 = duanxuan[dat];//��ѡ
	delay(30);
}

void main()
{
	EX1 = 1;
	IT1 = 1;
	EA = 1;
	
	while(1)
	{
		if (count == 0)
		{
			DisplaySMG(1,0);
			DisplaySMG(2,1);
			DisplaySMG(3,2);
			DisplaySMG(4,3);
		}
		else if (count == 1)
		{
			DisplaySMG(4,0);
			DisplaySMG(3,1);
			DisplaySMG(2,2);
			DisplaySMG(1,3);
		}

	}
}
void Int1() interrupt 2 //ע���жϺŰ���
{
	if (key == 0) // �жϰ����Ƿ���
	{
		count++;
		while(key == 0);//�ȴ��ɼ�
	}
	if (count == 2)
	{
		count = 0;
	}
}