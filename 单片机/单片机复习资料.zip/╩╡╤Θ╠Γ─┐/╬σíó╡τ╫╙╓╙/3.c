#include <STC12C5A60S2.H> //#include<reg51.h>

unsigned char count = 0;

void main()
{
	TMOD = 0X01;
	TH0 = (65535 - 50000)/256;//50ms��һ���ж�
	TL0 = (65535 - 50000)%256;
	TR0 = 1;
	ET0 = 1;
	EA = 1;
	
	while(1)
	{
		if (count >= 500)
		{
			P1 = 0X55;
		}
	}
		
		
}	

void T0() interrupt 1
{
	TH0 = (65535 - 50000)/256;//50ms��һ���ж�
	TL0 = (65535 - 50000)%256;
	count++;
}

