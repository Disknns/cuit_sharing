#include <STC12C5A60S2.H> //#include <reg51.h>

sbit LED = P2^4;
unsigned char count = 0;

void main()
{
	TMOD = 0X01;
	TH0 = (65535 - 25)/256; //50us��һ���ж�
	TL0 = (65535 - 25)%256;
	TR0 = 1;
	ET0 = 1;
	EA = 1;
	
	while(1);
}

void T0() interrupt 1
{
	TH0 = (65535 - 25)/256; //50us��һ���ж�
	TL0 = (65535 - 25)%256;
	
	count++;
	
	if (count<=1)
	{
		LED = 1;
	}
	if(count> 1)
	{
		LED = 0;
	}
	if(count==5)
	{
		count = 0;
	}

}