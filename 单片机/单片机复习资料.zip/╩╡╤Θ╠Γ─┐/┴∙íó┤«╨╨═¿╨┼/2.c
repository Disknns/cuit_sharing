#include <STC12C5A60S2.H> //#include <reg52.h>

void Send()
{
	unsigned char temp;
	
	while(RI == 0);
	RI = 0;
	temp = SBUF;
	
	if (temp >= '0' && temp <= '9')
	{
		if (temp < '5')
		{
			SBUF = 'R';
			while(TI == 0);
			TI = 0;
		}
		else
		{
			SBUF = 'K';
			while(TI == 0);
			TI = 0;
		}
	}

}

void main()
{
	TMOD = 0X20;
	SCON = 0X50;
	TH1 = TL1 = -5;
	TR1 = 1;
	
	while(1)
	{
		Send();
	}
}
