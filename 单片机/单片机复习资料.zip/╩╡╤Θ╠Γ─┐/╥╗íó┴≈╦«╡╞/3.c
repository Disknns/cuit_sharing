#include <STC12C5A60S2.H> //#include<AT89C52.h>

sbit key = P3^2;
unsigned char flag = 0;
void main()
{
	EX0 = 1;
	IT0 = 1;
	EA = 1;
	
	P2 = 0XFF;//Ĭ��ȫϨ��, �͵�ƽ��ͨ
	while(1)
	{
		if (flag == 1)
		{
			P2 = 0xaa;
		}
		else if(flag == 2)
		{
			P2 = 0x55;
		}
		
	}
}
void Int0() interrupt 0
{
	if (key == 0) // �жϰ����Ƿ���
	{
		flag++;
		while(key == 0);//�ȴ��ɼ�
	}
	if (flag == 3)
	{
		flag = 0;
	}
}