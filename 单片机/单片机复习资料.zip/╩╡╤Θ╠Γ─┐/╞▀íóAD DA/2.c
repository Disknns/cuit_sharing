#include <STC12C5A60S2.H> //#include <reg52.h>
#include "absacc.h"

unsigned char i;
void main()
{
	while(1)
	{
		for (i=0; i<=204; i++)
		{
			XBYTE[0X4000] = i;
		}
		
	}
}
