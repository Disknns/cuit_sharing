#include <STC12C5A60S2.H> //#include <reg52.h>
#include "absacc.h"

sbit INT0 = P3^2;
unsigned char temp;
void main()
{
	while(1)
	{
		XBYTE[0X7000] = 0xff;
		while(INT0 == 1);
		temp = XBYTE[0X7000];
	}
}
